<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="shortcut icon" type="x-icon" href="storage/photos/Web Logo.png">
    <title>Sign Up</title>
    <link rel="stylesheet" href="<?php echo e(asset('storage/css/Login.css')); ?>">
</head>
<body>
    <header class="header"> 
        <img src="storage/photos/Web Logo.png" alt="logo" width="120" height="120">
        <span class="logo-text" style="font-size: 5rem; font-family: Monaco, monospace">PaperTrail</span>
    </header>
    <div class="signup">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <h2>Sign Up</h2>
        <form method="POST" action="<?php echo e(route('signup')); ?>">
            <?php echo csrf_field(); ?>
            <input class="input-field" type="text" placeholder="First Name" name="FirstName" required><br>
            <input class="input-field" type="text" placeholder="Last Name" name="LastName" required><br>
            <input class="input-field" type="text" placeholder="Username" name="username" required><br>
            <input class="input-field" type="email" placeholder="Email" name="email" required><br>
            <input class="input-field" type="password" placeholder="Password" name="password" required><br>
            <select name="department" id="department">
                <option value="OSA">Office of Student Affairs (OSA)</option>
                <option value="DEAN">Dean</option>
                <option value="SAO">Student Accounting Office (SAO)</option>
                <option value="STUDENT">Student</option>
                <option value="Employee">Employee</option>
            </select><br>
            <button type="submit">Register</button>
        </form>
        <button><a href="<?php echo e(route('login')); ?>">Login</a></button>
    </div>
    
</body>
</html>
<?php /**PATH C:\laragon\www\Papertrail\resources\views/auth/signup.blade.php ENDPATH**/ ?>